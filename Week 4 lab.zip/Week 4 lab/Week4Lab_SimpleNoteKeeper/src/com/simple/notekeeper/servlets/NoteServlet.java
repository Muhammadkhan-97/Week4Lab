package com.simple.notekeeper.servlets;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.simple.notekeeper.models.Note;

/**
 * Servlet implementation class NoteServlet
 */
//@WebServlet("/note")
public class NoteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	// we use this method for get our text form notes
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// here we read our file
		String filePath = getServletContext().getRealPath("/WEB-INF/note.txt");
		File file = new File(filePath);
		if (file.exists()) {
			Note note = new Note();
			BufferedReader reader = new BufferedReader(new FileReader(file));
			String title = reader.readLine();
			// here we manage our null point exception and set our title
			note.setTitle(title != null ? title : "");
			StringBuilder contents = new StringBuilder();
			String line = reader.readLine();
			while (line != null) {
				contents.append(line).append("\n");
				line = reader.readLine();
			}

			// here we set our content
			note.setContents(contents.toString());
			request.setAttribute("note", note);
			reader.close();
			RequestDispatcher dispatcher = request.getRequestDispatcher("/viewnote.jsp");
			dispatcher.forward(request, response);
		} else {
			Note note = new Note();
			note.setTitle("");
			note.setContents("");
			request.setAttribute("note", note);
			RequestDispatcher dispatcher = request.getRequestDispatcher("/viewnote.jsp");
			dispatcher.forward(request, response);
		}
	}

	// using this method we post our data using /note url
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// here we read our file
		String filePath = getServletContext().getRealPath("/WEB-INF/note.txt");
		Note note = new Note();
		String title = request.getParameter("title");
		if (title == null || title.isEmpty()) {
			title = "";
		}
		note.setTitle(title);
		String contents = request.getParameter("contents");
		// here we manage our null point exception
		if (contents == null || contents.isEmpty()) {
			contents = "";
		}
		note.setContents(contents);
		PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(filePath, false)));
		pw.write(note.getTitle());
		pw.write(note.getContents());
		pw.close();
		request.setAttribute("note", note);
		RequestDispatcher dispatcher = request.getRequestDispatcher("/viewnote.jsp");
		dispatcher.forward(request, response);
	}
}
